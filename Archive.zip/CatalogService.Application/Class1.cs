﻿namespace CatalogService.Application;

public class Class1
{
}