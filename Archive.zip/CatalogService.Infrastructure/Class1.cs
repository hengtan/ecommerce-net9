﻿namespace CatalogService.Infrastructure;

public class Class1
{
}