﻿namespace CatalogService.Domain;

public class Class1
{
}